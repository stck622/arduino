﻿using System;
using System.Collections.Generic;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace LCD_Printer
{

    public partial class MainWindow : Window
    {

        SerialPort sp = new SerialPort();
        //시리얼 통신 객체

        Thread read;
        //수신 스레드 저장

        /// <summary>
        /// 수신데이터 읽고 할당하는 메소드
        /// </summary>
        void Serial_read()
        {
            while (true) //무한반복 스레드
            {
                String tmp = null;
                if (sp.IsOpen) //통신중일경우
                    tmp = sp.ReadLine(); //들어온 데이터 읽기
                Dispatcher.Invoke(DispatcherPriority.Normal, new Action(delegate
                //이구문은 ui 스레드 간섭 오류 해결을 위한 코드
                {
                    log_box.Text += tmp;
                    //로그블럭에 데이터 추가
                }));

            }
        }

        /// <summary>
        /// 통신포트 조회 메소드
        /// </summary>
        void get_com()
        {

            com_bt.Items.Clear();
            //콤보박스 초기화

            string[] ports = SerialPort.GetPortNames();
            //사용가능 포트 조회

            if (ports.Length == 0)
            {
                com_bt.Items.Add("connect please");
                //사용가능 포트가 없을경우 콤보박스에 커넥트 요청 등록
            }
            else
            {
                for (int i = 0; i < ports.Length; i++)
                {
                    com_bt.Items.Add(ports[i]);
                    //포트 하나씩 콤보박스에 등록
                }
            }
            com_bt.SelectedIndex = 0;
            //콤보박스 선택
        }

        /// <summary>
        /// 폼로드
        /// </summary>
        public MainWindow()
        {
            InitializeComponent();
            get_com();
            //포트 받아오기
        }

        /// <summary>
        /// 리프레쉬 버튼
        /// </summary>
        private void Refresh_bt_Click(object sender, RoutedEventArgs e)
        {
            get_com();
            //포트 받아오기
        }

        /// <summary>
        /// 커넥트 버튼 클릭
        /// </summary>
        private void Conn_bt_Click(object sender, RoutedEventArgs e)
        {
            if (!(sp.IsOpen)) //통신중이지 않을경우
            {
                sp = new SerialPort();
                //새 시리얼 객체 생성

                sp.PortName = com_bt.SelectedItem.ToString();
                //콤보박스에서 설정된 포트네임 가져오기

                sp.BaudRate = Convert.ToInt32(rate_box.Text);
                //textbox 에 입력된 보드레이트 가져오기

                sp.Open();
                //시리얼 커넥트

                read = new Thread(new ThreadStart(Serial_read));
                read.Start();
                //수신 스레드 시작

                conn_bt.Content = "close";
                //케넥트버튼 close 하기
            }
            else //시리얼 연결중일경우
            {
                read.Abort(); //수신스레드 종료
                sp.Close(); //커넥트 종료
                conn_bt.Content = "connect"; //클로즈버튼 connect 하기
            }
        }

        private void Send_bt_Click(object sender, RoutedEventArgs e)
        {
            if (sp.IsOpen) //시리얼 연결중일경우
            {
                sp.Write((send_box.Text) + "\0");
                //데이터 송신 + NULL문자
            }
            else //시리얼 연결중이 아닐경우
            {
                MessageBox.Show("Please connecting", "Warning");
                //메세지박스 띄우기
            }
        }
    }
}
