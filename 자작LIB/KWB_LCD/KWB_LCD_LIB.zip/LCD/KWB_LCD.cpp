#include "KWB_LCD.h"
#include "Arduino.h"


kwb_lcd::kwb_lcd(int RS, int RW, int EN, int D0, int D1, int D2, int D3, int D4, int D5, int D6, int D7)
{
	//�� ��� �Ҵ�.
	this->RS = RS;
	this->RW = RW;
	this->EN = EN;
	data_pin[0] = D0;
	data_pin[1] = D1;
	data_pin[2] = D2;
	data_pin[3] = D3;
	data_pin[4] = D4;
	data_pin[5] = D5;
	data_pin[6] = D6;
	data_pin[7] = D7;
}


void kwb_lcd::lcd_send_cmd(char data)
{
	digitalWrite(RS, LOW);
	digitalWrite(RW, LOW);

	unsigned char tmp = 0x01;

	for (int i = 0; i < 8; i++) {

		digitalWrite(data_pin[i], (tmp & data) > 0 ? HIGH : LOW);
		tmp = tmp << 1;;
	}

	digitalWrite(EN, HIGH);
	digitalWrite(EN, LOW);

	digitalWrite(RW, HIGH);
	digitalWrite(RS, HIGH);

	delayMicroseconds(100);
}


void kwb_lcd::lcd_send_char(char data) {

	digitalWrite(RS, HIGH);
	digitalWrite(RW, LOW);

	unsigned char tmp = 0x01;

	for (int i = 0; i < 8; i++) {

		digitalWrite(data_pin[i], (tmp & data) > 0 ? HIGH : LOW);
		tmp = tmp << 1;;
	}

	digitalWrite(EN, HIGH);
	digitalWrite(EN, LOW);

	digitalWrite(RW, HIGH);
	digitalWrite(RS, HIGH);


	delayMicroseconds(100);

	x++;
}


void kwb_lcd::lcd_init(int line) {

	for (int i = 0; i < 8; i++) {
		pinMode(data_pin[i], OUTPUT);
	}

	pinMode(RW, OUTPUT);
	pinMode(RS, OUTPUT);
	pinMode(EN, OUTPUT);

	lcd_send_cmd(0x30);
	lcd_send_cmd(0x30);
	lcd_send_cmd(0x30);

	lcd_send_cmd(0x38);
	lcd_send_cmd(0x06);
	lcd_send_cmd(0x0C);
	lcd_send_cmd(0x80);

	lcd_send_cmd(0x01);

	x = 0;
	y = 0;

	delay(100);

}

void kwb_lcd::lcd_clear() {
	lcd_send_cmd(0x01);
	x = 0;
	y = 0;
	//lcd �ʱ�ȭ�ϰ� Ŀ�� 0,0 ���� �̵�
}

void kwb_lcd::lcd_move(int y, int x) {
	this->x = x;
	this->y = y;
	lcd_send_cmd(register_map[y][x]);
	//������ ��ǥ�� �̵� Ŀ��� ����
}

void kwb_lcd::lcd_send_str(char* str) {

	for (int i = 0; i < strlen(str); i++) {

		if (str[i] == 10) { //new line
			x = 0;
			y += 1;
			lcd_move(y, x);
			//lcd �Ʒ��ٷ� �̵�
			continue;
		}
		else if (str[i] == 13) //carriage return
		{
			continue;
		}

		lcd_send_char(str[i]);
		//���� ����
	}
}
